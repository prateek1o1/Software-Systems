/*Name- Prateek Chhimwal
 *Roll Number- MT2022080
 *Write a program to display the environmental variable of the user (use environ).
*/

#include <stdio.h>

int main (void)
{
extern char **environ;
int item=0;

while(environ[item])
	{
	if(*((environ[item])+0)=='U' && *((environ[item])+4)=='=') //USER
	printf("%s\n",environ[item]);
	item++;
	}

return 0;
}
